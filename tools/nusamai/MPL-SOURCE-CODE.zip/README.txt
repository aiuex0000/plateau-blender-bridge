MPL-2.0 dependency sources for the PLATEAU Blender Bridge build of nusamai v0.1.19.
Original Cargo .crate archives, unmodified; SHA-256 values match Cargo.lock.

option-ext-0.2.0.crate  SHA-256 04744f49eae99ab78e0d5c0b603ab218f515ea8cfe5a456d7629ad883a3b6e7d  https://crates.io/crates/option-ext/0.2.0
