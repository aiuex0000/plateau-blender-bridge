MPL-2.0 dependency source archives for the nusamai v0.1.19 Windows-target metadata inventory.
These are original Cargo .crate archives, unmodified; SHA-256 values match Cargo.lock.

attohttpc 0.30.1 — MPL-2.0 — https://crates.io/crates/attohttpc/0.30.1
option-ext 0.2.0 — MPL-2.0 — https://crates.io/crates/option-ext/0.2.0
License text: Mozilla Public License 2.0, included in THIRD_PARTY_LICENSES-nusamai.txt.
Source graph: pinned MIERUNE/plateau-gis-converter v0.1.19 Cargo.lock, Windows x86_64-msvc
metadata resolution with default features. Presence in graph is not an exact link map for the exe.

Archive checksums:
attohttpc-0.30.1.crate  SHA-256 16e2cdb6d5ed835199484bb92bb8b3edd526effe995c61732580439c1a67e2e9 (verified against Cargo.lock)
option-ext-0.2.0.crate  SHA-256 04744f49eae99ab78e0d5c0b603ab218f515ea8cfe5a456d7629ad883a3b6e7d (verified against Cargo.lock)
